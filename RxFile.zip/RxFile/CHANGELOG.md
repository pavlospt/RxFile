# Change Log

`Version 1.3`
9-12-2015: Added methods for file MultiSelection.